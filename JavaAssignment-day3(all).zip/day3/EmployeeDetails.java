package assignment.letsupgrade.day3;

import java.util.Scanner;

public class EmployeeDetails {

	public static void main(String[] args) {
	
		String name;
		int dateOfBirth;
		int monthOfBirth;
		int yearOfBirth;
		int monthlySalary;
		int annualSalary;
		double taxAmount = 0.0;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Name of the Employee: ");
		name = sc.nextLine();
		
		System.out.println("Enter the Date of Birth (only date): ");
		dateOfBirth = sc.nextInt();
		
		System.out.println("Enter the Month of Birth (in numbers): ");
		monthOfBirth = sc.nextInt();
		
		System.out.println("Enter the Year of Birth: ");
		yearOfBirth = sc.nextInt();
		
		System.out.println("Enter the Monthly Salary of the Employee: ");
		monthlySalary = sc.nextInt();
		
		annualSalary = monthlySalary * 12;

		if(annualSalary > 500000) {
			taxAmount = annualSalary * (0.20);
		} else if (annualSalary >= 400000 && annualSalary <= 500000 ) {
			taxAmount = annualSalary * (0.15);
		} else if (annualSalary >= 300000 && annualSalary <= 400000 ) {
			taxAmount = annualSalary * (0.10);
		} else if (annualSalary >= 300000 && annualSalary <= 200000 ) {
			taxAmount = annualSalary * (0.05);
		}
		
		System.out.println("Name of the Employee: " + name);
		System.out.println("Age: " + (2020 - yearOfBirth));
		System.out.println("Annual Salary: Rs." + annualSalary);
		System.out.println("Tax Amount: Rs." + taxAmount);
	}

}