package assignment.letsupgrade.day3;

import java.util.Scanner;

public class SubjectGrades {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		subjectDetails[] subjectDtls = new subjectDetails[5];
		
		for(int i=0; i<subjectDtls.length; i++) {
			int subjectNo = i+1;
			System.out.print("Enter the name of the Subject-" + subjectNo + ": ");
			
			subjectDtls[i] = new subjectDetails();
			subjectDtls[i].nameOfSubject = sc.nextLine();
			System.out.print("Enter the Marks: ");
			
			subjectDtls[i].marks = sc.nextInt();
			sc.nextLine();
			subjectDtls[i].percentage = subjectDtls[i].marks;
			
			if(subjectDtls[i].percentage >= 75) {
				subjectDtls[i].grade = "Distinction";
			} else if(subjectDtls[i].percentage >= 60 && subjectDtls[i].percentage <= 75) {
				subjectDtls[i].grade = "First Class";
			} else if(subjectDtls[i].percentage >= 40 && subjectDtls[i].percentage <= 60) {
				subjectDtls[i].grade = "Pass";
			} else if(subjectDtls[i].percentage < 40) {
				subjectDtls[i].grade = "Fail";
			}
		}
		
		System.out.println("Subject-wise Percentage & Grade: \n");
		for(int i=0; i<subjectDtls.length; i++) {
			System.out.println();
			System.out.println("Subject Name: " + subjectDtls[i].nameOfSubject);
			System.out.println("Marks: " + subjectDtls[i].marks);
			System.out.println("Percentage: " + subjectDtls[i].percentage + "%");
		}
		
		if(sc!=null) {
			sc.close();	
		}
		
	}

}

class subjectDetails {
	String nameOfSubject;
	int marks;
	int percentage;
	String grade;
}