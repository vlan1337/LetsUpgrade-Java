package assignment.letsupgrade.day5;

public class QuizMain {
	public static void main(String[] args) {
		Game game = new Game();
		game.initGame();
		game.play();
	}
}