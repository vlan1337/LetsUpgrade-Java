package assignment.letsupgrade.day5;

import java.util.Scanner;

public class Player {

	Scanner sc = new Scanner(System.in);
	String userName;
	int score = 0;
	
	public void getDetails() {
		System.out.println("Enter the player name:");
		userName = sc.nextLine();
	}
	
}