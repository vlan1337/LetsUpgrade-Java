package assignment.letsupgrade.day4;

import java.util.Scanner;

public class IntArrayUserInput {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int arr[] = new int[5];
		int sum = 0;
		
		for(int i=0;i<arr.length;i++) {
			System.out.println("Enter an integer value: ");
			arr[i] = sc.nextInt();
			sum = sum + arr[i];
		}
		
		System.out.println("Sum of all the elements in the array: " + sum);

		if(sc!=null) {
			sc.close();
		}
	}

}