package assignment.letsupgrade.day4;

import java.util.Scanner;

public class Avenger {

	String name;
	int age;
	int power;
	String weapon;
	String planet;
	
	Scanner sc = new Scanner(System.in);

	public void getDetails() {
		System.out.println("Enter the Name of the Avenger: ");
		name = sc.nextLine();
		
		System.out.println("Enter the Age of the Avenger: ");
		age = sc.nextInt();
		
		System.out.println("Enter the Power: ");
		power = sc.nextInt();
		
		sc.nextLine();
		System.out.println("Enter the Weapon he has: ");
		weapon = sc.nextLine();
		
		System.out.println("Enter the planet to which the Avenger belongs to: ");
		planet = sc.nextLine();
	}
	
	public void displayDetails() {
		System.out.println("Name of the Avenger: " + name);
		System.out.println("Age : " + age);
		System.out.println("Power : " + power);
		System.out.println("Avenger's Weapon : " + weapon);
		System.out.println("Avenger's Planet : " + planet);
	}
	
	public static void main(String[] args) {
		Avenger[] avengers = new Avenger[5];
		for(int i=0;i<5;i++) {
			System.out.println("Enter the details of the Avenger-" + i);
			avengers[i] = new Avenger();
			avengers[i].getDetails();
		}
		for(int i=0;i<5;i++) {
			System.out.println("Details of the Avenger-" + i);
			avengers[i].displayDetails();
		}
	}
	
}